<table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
    <tbody>
        <tr>
            <th><?php echo $this->lang->line('school_name'); ?></th>
            <td><?php echo $openinghour->school_name; ?></td> 
        </tr>
        <tr>
            <th><?php echo $this->lang->line('monday'); ?></th>
            <td><?php echo $openinghour->monday; ?></td>  
        </tr>
       <tr>
            <th><?php echo $this->lang->line('tuesday'); ?></th>
            <td><?php echo $openinghour->tuesday; ?></td>        
        </tr>
        <tr>
            <th><?php echo $this->lang->line('wednesday'); ?></th>
            <td><?php echo $openinghour->wednesday; ?></td>         
        </tr>
        <tr>
            <th><?php echo $this->lang->line('thursday'); ?></th>
            <td><?php echo $openinghour->thursday; ?></td>         
        </tr>
        <tr>
            <th><?php echo $this->lang->line('friday'); ?></th>
            <td><?php echo $openinghour->friday; ?></td>        
        </tr>
        <tr>
            <th><?php echo $this->lang->line('saturday'); ?></th>
            <td><?php echo $openinghour->saturday; ?></td>       
        </tr>
        <tr>
            <th><?php echo $this->lang->line('sunday'); ?></th>
            <td><?php echo $openinghour->sunday; ?></td>          
        </tr>
    </tbody>
</table>
